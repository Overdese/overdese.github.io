---
layout: post
title: "Восстановление админовских шар"
date: 2013-05-16 12:31
comments: true
categories: [windows, registry]
description: "Восстановления админовскийх шар при перезагрузке"
keywords: "admin$, c$, share"
---

При бурной жизнедеятельности вирусных организмов на компе или по другим причинам могут пропасть скрытые админовские сетевые ресурсы на компе.
Их восстановить очень просто, для это в реестре нужно изменить в ветке
```
	HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\lanmanserver\parameters
```
параметры `AutoShareServer` и `AutoShareWks` изменить на 1.

После ребута утерянные шары появятся.