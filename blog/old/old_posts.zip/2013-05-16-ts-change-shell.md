---
layout: post
title: "Запуск приложения в качестве основного шелла на Microsoft Terminal Server в зависимости от группы из Active Directory"
date: 2013-05-16 11:25
comments: true
categories: [windows, bat, Active Directory, Terminal Server]
description: "Скрипт для определения группы из AD и запуска подходящего приложения на примере 1С предприятие"
keywords: "vbs скрипт active directory, vbs получить группу из Active Directory, запуск вместо шелла на сервере терминалов, vbs ad script"
---

VBS-cкрипт проверяет принадлежность юзера, зашедшего на сервер терминалов, к определенный группе в AD и запускает вместо шелла нужно приложение( в данном случае приложение `1С` и группа `1C_USER`), в противном случае дефолтный `explorer.exe`.


<!-- more -->

```

'==========================================================================  
'  
' VBScript Source File  
' 
' COMMENT:  Проверка принадлежности юзера к группе и запуск основного шелла в итоге
'  
'==========================================================================  
Option Explicit  
'On Error Resume Next  
  
Dim WshShell, WshNetwork  
Dim strUserDN, objSysInfo, GroupObj, UserGroups, UserObj 
 
UserGroups=""    
 
  
Set WshShell = WScript.CreateObject("WScript.Shell")  
Set objSysInfo = CreateObject("ADSystemInfo")   
 
strUserDN = objSysInfo.userName   
 
Set UserObj = GetObject("LDAP://" & strUserDN)   
 
For Each GroupObj In UserObj.Groups    
        UserGroups=UserGroups & "[" & GroupObj.Name & "]"    
Next    

if InGroup("1C_Users") then    
	'--------------------------------------------------------------------------------------------------------
	WshShell.Run "1cv7s.exe"
	WshShell.Run "regedit.exe /s D:\AutoStart\1c_options.reg"
	'--------------------------------------------------------------------------------------------------------
else
	'--------------------------------------------------------------------------------------------------------	
	WshShell.Run "explorer.exe"
	'--------------------------------------------------------------------------------------------------------	
end if   
'==========================================================================  
'  
' Function InGroup(strGroup) 
'  
' strGroup - группа, принадлежность к которой проверяем 
'  
' COMMENT: проверка принадлежности пользователя к группе 
'  
'==========================================================================  
 
Function InGroup(strGroup)    
        InGroup=False    
        If InStr(UserGroups,"[CN=" & strGroup & "]") Then    
                InGroup=True    
        End If    
End Function

```

Создадим reg-файл с настройками профиля пользователя:

```
REGEDIT4

[HKEY_CURRENT_USER\Control Panel\International]
"iCountry"="7"
"iCurrDigits"="2"
"iCurrency"="1"
"iDate"="1"
"iDigits"="2"
"iLZero"="1"
"iMeasure"="0"
"iNegCurr"="5"
"iTime"="1"
"iTLZero"="0"
"Locale"="00000419"
"s1159"=""
"s2359"=""
"sCountry"="Russia"
"sCurrency"="р."
"sDate"="."
"sDecimal"=","
"sLanguage"="RUS"
"sList"=";"
"sLongDate"="d MMMM yyyy 'г.'"
"sShortDate"="dd.MM.yyyy"
"sThousand"="."
"sTime"=":"
"DefaultBlindDialFlag"=hex:00
"sTimeFormat"="H:mm:ss"
"iTimePrefix"="0"
"sMonDecimalSep"=","
"sMonThousandSep"="."
"iNegNumber"="1"
"sNativeDigits"="0123456789"
"NumShape"="1"
"iCalendarType"="1"
"iFirstDayOfWeek"="0"
"iFirstWeekOfYear"="0"
"sGrouping"="3;0"
"sMonGrouping"="3;0"
"sPositiveSign"=""
"sNegativeSign"="-"

[HKEY_CURRENT_USER\Control Panel\International\Geo]
"Nation"="203"

[HKEY_CURRENT_USER\Keyboard Layout]

[HKEY_CURRENT_USER\Keyboard Layout\IMEtoggle]

[HKEY_CURRENT_USER\Keyboard Layout\IMEtoggle\scancode]

[HKEY_CURRENT_USER\Keyboard Layout\Preload]
"1"="00000409"
"2"="00000419"

[HKEY_CURRENT_USER\Keyboard Layout\Substitutes]

[HKEY_CURRENT_USER\Keyboard Layout\Toggle]
"Hotkey"="2"
"Language Hotkey"="2"
"Layout Hotkey"="1"

[HKEY_CURRENT_USER\Control Panel\Desktop]
"SCRNSAVE.EXE"=""
"ScreenSaveActive"="0"
"ScreenSaverIsSecure"="1"
"ScreenSaveTimeOut"="600"

[HKEY_CURRENT_USER\Software\Microsoft\Plus!\Themes\Apply]
"Screen saver"="1"
"Sound events"="1"
"Mouse pointers"="1"
"Desktop wallpaper"="1"
"Icons"="1"
"Colors"="1"
"Font names and styles"="1"
"Font and window sizes"="1"
"Rotate theme monthly"="1"

[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\LastTheme]
"ThemeFile"=hex(2):00
"Wallpaper"=hex(2):00
"DisplayName of Modified"="Modified Theme"
```

Осталось только на сервере терминалов в качестве среды указать наш vbs-скрипт. 