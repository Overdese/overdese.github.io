---
layout: post
title: "Восстановление репликации папкок sysvol и netlogon между двумя контроллерами домена"
date: 2013-05-16 12:42
comments: true
categories: [windows, Active Directory]
description:
keywords: "active directory netlogon sysvol repare, active directory восстановление репликации"
---

Поменял ключик в реестре:
```
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NTDS\Parameters]
"Strict Replication Consistency"=dword:00000000
```
затем:
```
net stop ntfrs
net start ntfrs
```

Ждал пока восстановиться, затем поставил в единуцу его
```
Strict Replication Consistency"=dword:00000001
```
```
net stop ntfrs
net start ntfrs
```
<!--more-->
Затем отключил на BDC службу ntfrs с некорректно работающей репликацией:
```
net stop ntfrs
```
перенес на нем
`C:\WINDOWS\sysvol\sysvol\domain-name.local` в другое место, на том же месте `C:\WINDOWS\sysvol\sysvol\`, создал пустую папку с названием `domain-name.local`, где `domain-name.local` - имя домена.
Используя утилиты из Windows Rescue Kit прилинковал к созданной папке каталог `%systemroot%\sysvol\domain`
```
linkd “C:\WINDOWS\sysvol\sysvol\domain-name.local” %systemroot%\sysvol\domain и второй каталог прилинковал
linkd “C:\WINDOWS\sysvol\staging areas\domain-name.local” %systemroot%\sysvol\staging\domain
```

Далее включил службу репликации
```
net start ntfrs
```
Один товарисч рассписал поглобальнее http://liond.livejournal.com/4293.html

Если так получилось, что на контроллере домена по каким-то причинам пропал общий ресурс SYSVOL и в журнале пишется предупреждение:

>Служба репликации файлов просматривает данные на системном томе. Компьютер SERVER1 не сможет стать контроллером домена, пока этот процесс не завершится. Затем системный том станет общим ресурсом с именем SYSVOL.

Для проверки ресурса SYSVOL введите в командной строке:
```
net share
```
Когда служба репликации файлов завершит процесс сканирования, на экране появится общий ресурс `SYSVOL`.  
Инициализация системного тома может занять некоторое время. Это время зависит от объема системного тома.

И длительное время ничего не происходит, то есть сервер снова не становится контроллером домена, то надо переходить к восстановлению службы `NTFRS`.

В моём случае эта проблема образовалась после исправления следующего предупреждения в журнале:

>Служба репликации файлов обнаружила, что набор реплик "DOMAIN SYSTEM VOLUME (SYSVOL SHARE)" находится в JRNL_WRAP_ERROR.  
>
>Имя набора реплик : "DOMAIN SYSTEM VOLUME (SYSVOL SHARE)"  
>Путь к корню реплики : "C:\winnt\sysvol\domain"  
>Том корня реплики : "\\.\C:"  
>Набор реплик попадает в JRNL_WRAP_ERROR, когда запись, которую пытаются прочесть из USN-журнала NTFS, не найдена. Это может произойти по одной из следующих причин.  
>
>[1] Том "\\.\C:" был отформатирован.  
>[2] Удален USN-журнал NTFS на томе"\\.\C:".  
>[3] USN-журнал NTFS на томе"\\.\C:" был урезан. Программа Chkdsk может урезать журнал, если она находит поврежденные записи в конце журнала.  
>[4] Служба репликации файлов в течение долгого времени не работала на этом компьютере.  
>[5] Службе репликации файлов не удалось сохранить уровень активности дискового ввода/вывода на "\\.\C:".  
>
>Присвоение параметру системного реестра "Enable Journal Wrap Automatic Restore" значения 1 приведет к выполнению следующих автоматических шагов по восстановлению из данного ошибочного состояния.  
>[1] Во время первого опроса, который происходит в течение 5 минут, этот компьютер будет удален из набора реплик. Если вы не хотите ждать 5 минут, выполните последовательно команды "net stop ntfrs" и "net start ntfrs" для перезапуска службы репликации файлов.  
>[2] Во время следующего опроса, этот компьютер будет вновь добавлен к набору реплик. Повторное добавление компьютера инициирует полную синхронизацию дерева для данного набора реплик.  
>
>ПРЕДУПРЕЖДЕНИЕ: В процессе восстановления данные в дереве реплик могут быть недоступны. Для предотвращения неожиданного прекращения доступа к данным службой автоматического восстановления в подобной ошибочной ситуации необходимо задать значение 0 для параметра системного реестра, описанного ранее.

Эту проблему я решал присвоением параметру системного реестра `"Enable Journal Wrap Automatic Restore"` значения 1 и перезапуском службы NTFRS.

Но после перезагрузки сервера SYSVOL пропал и контроллер не поднимался, соответственно, у пользователей не проходила аутентификация, так как указанный домен не функционировал.

Оригинальная статья на английском языке (описанные действия немного отличаются от моих).

Итак, чтобы восстановить SYSVOL службы NTFRS я делал следующие шаги:

1. Останавливаем службу ntfrs на всех контроллерах домена.
```
net stop ntfrs
```

2. Проверяем наличие папок на всех контроллерах домена.
```
\SYSVOL
\SYSVOL\domain
\SYSVOL\staging\domain
\SYSVOL\staging areas
\SYSVOL\domain\Policies
\SYSVOL\domain\scripts
\SYSVOL\SYSVOL
```
Если этих папок нет, то создайте их вручную.

3. Проверяем ссылки с помощью утилиты `linkd`.

`Linkd` входит в комплект утилит [Windows Resource Kit Tools](http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=9d467a69-57ff-4ae7-96ee-b18c4790cffd)

Проверка первой ссылки:
```
linkd “%systemroot%\SYSVOL\SYSVOL\domain.local”
```

где `domain.local` нужно заменить именем своего домена.

Если команда выполнится успешно, то будет выдано сообщение:
Для Win2000:
Cannot create a link at: C:\WINNT\SYSVOL\staging\domain
Для Win2003:
Source C:\WINDOWS\SYSVOL\SYSVOL\domain.local is linked to С:\WINDOWS\SYSVOL\domain

Проверка второй ссылки:
```
linkd “%systemroot%\SYSVOL\staging areas\domain.local”
```

Если команда выполнится успешно, то будет выдано сообщение:
Для Win2000:
Cannot create a link at: C:\WINNT\sysvol\staging
Для Win2003:
C:\WINDOWS\SYSVOL\staging\domain

Если проверка обоих ссылок прошла успешно, то переходим к пункту 5, иначе производим восстановление ссылок на пункте 4.

4. Восстанавливаем ссылки с помощью утилиты linkd.

Для Win2000:
```
linkd “C:\WINNT\sysvol\sysvol\domain.local” %systemroot%\sysvol\domain
linkd “C:\WINNT\sysvol\staging areas\domain.local” %systemroot%\sysvol\staging\domain
```
Для Win2003:
```
linkd “C:\WINDOWS\sysvol\sysvol\domain.local” %systemroot%\sysvol\domain
linkd “C:\WINDOWS\sysvol\staging areas\domain.local” %systemroot%\sysvol\staging\domain
```

и снова повторяем пункт 3.

5. Редактируем ключи в реестре контроллеров домена.

Для корневого контроллера домена:

создаём параметры типа `DWord` с именем `BurFlags` и со значением `D4` в разделах:
```
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NtFrs\Parameters\Cumulative Replica Sets\GUID
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NtFrs\Parameters\Replica Sets\GUID
```

где вместо GUID у вас имеется своя последовательность букв и цифр, разделённых дефисами.

Для вспомогательных контроллеров домена заходим в разделы:  
создаём параметры типа `DWord` с именем `BurFlags` и со значением `D2` в разделах:
```
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NtFrs\Parameters\Cumulative Replica Sets\GUID
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NtFrs\Parameters\Replica Sets\GUID
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NtFrs\Parameters\Backup/Restore\Process atStartup\
```
где вместо GUID у вас имеется своя последовательность букв и цифр, разделённых дефисами.

6. Переносим содержимое папок в любое другое место.

Для Win2000 переносим содержимое из папок:
```
C:\WINNT\SYSVOL\domain\policies\GUID
C:\WINNT\SYSVOL\staging\domain
```
Для Win2003 переносим содержимое из папок:
```
C:\WINDOWS\SYSVOL\domain\policies\GUID
C:\WINDOWS\SYSVOL\staging\domain
```

7. Запускаем службы `ntfrs` на всех контроллерах.

Запуск служб нужно начинать сначала на корневом контроллере домена, а затем на дополнительных контроллерах домена.
```
net start ntfrs
```
8. Копируем обратно содержимое папок.

Для Win2000:
```
C:\WINNT\SYSVOL\domain\policies\GUID
C:\WINNT\SYSVOL\staging\domain
``` 
Для Win2003:
```
C:\WINDOWS\SYSVOL\domain\policies\GUID
C:\WINDOWS\SYSVOL\staging\domain
```
9. Проверяем результат на всех контроллерах домена.
```
net share
```
Если в результате выполнения команды `net share` видно наличие расшаренных папок `Netlogon` и `Sysvol`, значит восстановление NTFRS успешно завершено.