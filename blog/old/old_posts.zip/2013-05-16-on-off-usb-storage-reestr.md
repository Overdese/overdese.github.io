---
layout: post
title: "Включение и выключение USB-flash/HDD устройств через реестр"
date: 2013-05-16 12:03
comments: true
categories: [windows, registry]
description: 
keywords: ""
---

Иногда у системных администраторов, в основном для повышения безопасности, возникает необходимость ограничивать пользователей в использовании usb-сторадж девайсов.
Самое простое и нативное, что можно придумать это управление устройствами через реестр:

Для включения:
```
Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR]
"Start"=dword:00000003
```
И соответсвенное для выключения:
```
Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR]
"Start"=dword:00000004
```
Данные махинации были опробованы на ОС Windows XP
