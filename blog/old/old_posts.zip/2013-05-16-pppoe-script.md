---
layout: post
title: "Установка и перезапуск PPPoE соединения через bat-скрипт"
date: 2013-05-16 09:45
comments: true
categories: [PPPoE, windows, bat]
description: 
keywords: "pppoe windows batch file, pppoe через батник, bat-файл для pppoe"
---
В даном скрипте нужно заменить (при желании) адрес хоста, который пингуется (`set host = ya.ru`), таймаут пинга (`set TimeOut = 10000`), количество попыток пинга (`set MaxPing = 5`) после которого будет переподключение, интервал проверки соединения (`set Pause = 30`) а так же ***ОБЯЗАТЕЛЬНО*** меняем имя подключения (`set DialName = Life`) (смотрим имя: Пуск - Настройки - Сетевые подключения - имя Вашего подключения) и логин/пароль (`set Login=Login set Pass=Password`) - если это требуется для установки соединения.

<!-- more -->

``` bat pinger.cmd 
@echo off
echo %date% %time% --- STARTED --- >> pinger.log
set Try=1

rem Все настройки вынесены в этот блок

rem имя подключения
set DialName=Life
rem Логин
set Login=Login
rem Пароль
set Pass=Password
rem таймаут пинга в мс
set TimeOut=10000
rem количество попыток пинга
set MaxPing=5
rem пауза в с
set Pause=30
rem адрес хоста для пинга
set host=ya.ru
rem свой телефонный номер
set PhoneNum=80631234567

:start
echo.
echo start ping
ping %host% -n 1 -w %TimeOut%
if errorlevel=1 goto bad
goto ok

:ping
echo.
ping %host% -n 1 -w %TimeOut%
if not errorlevel=1 goto ok
set /a Try=%Try%+1
if %Try% geq %MaxPing% goto bad
goto ping

:ok
echo.
echo ALL RIGHT
goto end

:bad
set /a Try=1
echo.
echo BAD CONNECT
echo %date% %time% --! Trouble, reconnect !-- >> pinger.log
rasdial %DialName% /disconnect
rasdial %DialName% /phone:%PhoneNum%
rasdial %DialName% %Login% %Pass%
if errorlevel=1 goto bad
goto ping

:end
set /a Try=1
echo.
choice /C:PRDE /T:P,30 /N Pause 30 seconds. [P]ing [R]econnect [D]isconnect [E]xit?
rem echo.
rem echo.
goto %ERRORLEVEL%
:1
goto ping
:2
goto bad
:3
rasdial %DialName% /disconnect
:4
echo %date% %time% == Exit script == >> pinger.log

```


