---
layout: post
title: "Backupexec 2010 загружает файл threatcon.zip каждые пять минут"
date: 2013-05-16 13:32
comments: true
categories: windows
description: 
keywords: "Backupexec 2010, threatcon.zip, symantec"
---

1.Запускаем редакор реестра  
2.Ищем:  
```
HKLM\Software\Symantec\Backup Exec For Windows\Backup Exec\Server
```
3.Добавляем новый параметр Создать -> DWORD  `DisableThreatconStatusPolling`. И устанавливаем его в 1  
4.Перезапускаем Backup Exec Services  