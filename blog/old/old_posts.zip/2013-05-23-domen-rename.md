---
layout: post
title: "Переименования домена Active Directory под управлением ОС Windows Server 2003"
date: 2013-05-23 08:41
comments: true
categories: [Active Directory, windows, howto]
keywords: "active directory, domane rename, переименование домена"
---
Столкнулся с доменом под ОС Windows 2k3S у которого DNS-имя состоит из одной метки(т.е. DomainName). Данное положение вещей меня ни как не устраивало, да и сам Microsoft не рекомендует, и я решил переименовать домен.  
Если кто-то все же хочет юзать далее однокомпонентное DNS-имя, то я бы рекомендовал к прочтению данную статью: [Сведения о настройке Windows для доменов с DNS-именем, состоящим из одной метки](http://support.microsoft.com/kb/300684/ru).  
Здесь ниже я приведу небольшой алгоритм по которому я и произвел процедуру переименования.  
**Обязательно** для ознакомления [официальный мануал от Microsoft](http://download.microsoft.com/download/c/f/c/cfcbff04-97ca-4fca-9e8c-3a9c90a2a2e2/Domain-Rename-Procedure.doc) или ищем на оффсайте документы `domain-rename-intro.doc`, `domain-rename-procedure.doc`, `domain-rename-readme.doc`, качаем и курим!  
<!-- more -->

Сделаю небольшую вводную:

1. Имя домена домена `Domain`
2. В сети имелось 2 контроллера домена:
   1. `dc1.Domain` - PDC, хозяин ролей FSMO и глобальный каталог  
   2. `dc2.Domain` - BDC и глобальный каталог  
3. Не используются DFS, Exchange, OCS и подобные сервисы, завязанные на AD.  

И сообственно процедура:

1. С помощью утилит `dcdiag.exe` и `netdiag.exe` ищем ошибки в работе Active Direvtory, при нахождении лечим, а уже потом переходим к п.2.
2. Понижаем количество контроллеров домена до минимально возможного, в нашем случае до 1. С помощью `dcpromo.exe` понижаем роль `dc2.Domain` до рядового сервера.
3. Разворачиваем на  машину управления Windows 2k3S, загоняем в наш домен  и инсталлируем:
   1. `Support tools` - должен быть на установочном диске
   2. `Domain Rename Tools` - берем с [оффсайта](http://technet.microsoft.com/en-us/windowsserver/bb405948.aspx), для удобства можно добавить в `PATH` путь до экзешников.
4. На DNS-сервере добавляем новую зону прямого просмотра, старую зону не трогаем. На DNS-сервере `dc1.domain`  добавляем зону прямого просмотра `Domain.local`
5. На управляющей машине логинемся под учеткой с правами админом домена, запускаем консоль и ...
6. `rendom /list`. Должен будет создаться файлик `domainlist.xml`.
7. Обычным `notepad.exe` открываем этот файл и заменяем все вхождения ограниченные тегами `<DNSname></DNSname>` и `<NetBiosName></NetBiosName>` на новые имена. `ForestDnsZOnes` и `DomainDNSZones` оставляем. Между тэгами `<DcName></DcName>` надо указать контроллер домена с которого получаем данные. Пример файлов приведу чуть ниже.
8. Проверяем изменения с помощью `rendom /showforest`
9. Готовим инструкции `rendom /upload`. Должен появиться `dclist.xml`, который будет использоваться для отслеживания всех изменений. На текущем этапе у всех DC должно быть `<State>Initial</State>`
10. Загружаем инструкции `Dsquery server –hasfsmo name`. Ecли контроллеров домена больше одного, то следует запустить репликацию.
11. `rendom /prepare`. И проверям в `dclist.xml`, чтобы все DC были в `<State>Prepared</State>`
12. И поехали! `rendom /execute`. В `dclist.xml` все DC должны встать в `<State>Done</State>` и те DC которые успешно усе прошли **сами уйдут в перезагрузку**.
13.	Фиксим Group Policy `gpfixup /olddns :domain /newdns:domain.local /oldnb :domain /newnb:domain /dc :dc1.domain 2>&1 >gpfixup.log `. Проверяем gpfixup.log на наличие ошибок. Ecли контроллеров домена больше одного, то следует запустить репликацию.
14. Фиксим ссылки в `Administrative Tools` на `Domain Security Policy` и `Domain Controller Security Policy`. Там нужно прописать новые DN домена.
15. Размораживаем лес `rendom /end`
9. Смена DNS-суффиксов:
   1. Меняем DNS суффикс на всех контроллерах домена. Автоматом на DC он не меняется, для этого используем утилиту `netdom`, оффициальный мануал: http://technet.microsoft.com/en-us/library/cc782761(v=ws.10).aspx
   2. 2 раза перезагрузить остальные сервера. Проверить, если не поменялся DNS-суффикс, то поменять руками
   3. Клиентские ПК перезагрузить 2 раза и проверить. Обычно все происходит автоматом.
17. **После того как все компы вошли в новый домен.** Завершаем операцию переименования `rendom /clean`

Останется только проверить все имеющиеся в сети сервисы и посмотреть, не сломались ли они от смены имени. А лучше такие вещи посмотреть до переименования, и узнать заблаговременно чего ждать.

Содержимое файла `domainlist.xml` до изменения:  
``` xml
<?xml version ="1.0"?>
<Forest>
	<Domain>
		<!-- PartitionType:Application -->
		<Guid>1615a64d-48c5-4d07-9455-1d8fada8be64</Guid>
		<DNSname>DomainDnsZones.DOMAIN</DNSname>
		<NetBiosName></NetBiosName>
		<DcName></DcName>
	</Domain>
	<Domain>
		<!-- PartitionType:Application -->
		<Guid>e9e065cd-149e-4ad3-9a1c-672d138df1ca</Guid>
		<DNSname>ForestDnsZones.DOMAIN</DNSname>
		<NetBiosName></NetBiosName>
		<DcName></DcName>
	</Domain>
	<Domain>
		<!-- ForestRoot -->
		<Guid>6285681a-18fd-4310-8a11-ed08fe0933d2</Guid>
		<DNSname>DOMAIN</DNSname>
		<NetBiosName>DOMAIN</NetBiosName>
		<DcName></DcName>
	</Domain>
</Forest>
```

Содержимое файла `domainlist.xml` после изменения:   
``` xml
<?xml version ="1.0"?>
<Forest>
	<Domain>
		<!-- PartitionType:Application -->
		<Guid>1615a64d-48c5-4d07-9455-1d8fada8be64</Guid>
		<DNSname>DomainDnsZones.DOMAIN.local</DNSname>
		<NetBiosName></NetBiosName>
		<DcName></DcName>
	</Domain>
	<Domain>
		<!-- PartitionType:Application -->
		<Guid>e9e065cd-149e-4ad3-9a1c-672d138df1ca</Guid>
		<DNSname>ForestDnsZones.DOMAIN.local</DNSname>
		<NetBiosName></NetBiosName>
		<DcName></DcName>
	</Domain>
	<Domain>
		<!-- ForestRoot -->
		<Guid>6285681a-18fd-4310-8a11-ed08fe0933d2</Guid>
		<DNSname>DOMAIN.local</DNSname>
		<NetBiosName>DOMAIN</NetBiosName>
		<DcName></DcName>
	</Domain>
</Forest>
```

